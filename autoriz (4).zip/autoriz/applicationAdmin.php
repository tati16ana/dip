<?php

 session_start();
 	include 'connect.php';

?>





<!DOCTYPE html>
<html lang="en">
<head>
	<!-- <meta http-equiv="Refresh" content="1" /> -->

	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Заявки на консультирование</title>
	<link rel="stylesheet" href="styleappAdmin.css">

	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">


 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/css/bootstrap.min.css" integrity="sha384-r4NyP46KrjDleawBgD5tp8Y7UzmLA05oM1iAEQ17CSuDqnUK2+k9luXQOfXJCJ4I" crossorigin="anonymous">
  <style  
        type="text/css" media="all">
        @import url("styleappAdminProb.css");
  </style>

</head>


<body>




<nav class="navbar">
	<div class="logo">
	<li><a href="profileuser2.php">Профиль</a></li>	
	</div>	
	<ul class="nav-lonks">
		<input type="checkbox" id="checkbox_toggle" />
		<label for="checkbox_toggle" class="hamburger"><span class="hamburger-line"></span></label>
		<div class="menu">
					<li><a href="applicationAdmin.php">Заявки на консультирование</a></li>	
					<li><a href="reservationAdmin.php">Бронирование квартиры</a></li>	
					<li><a href="profileUsersAdmin.php">Профили пользователей</a></li>
					<li><a href="logout.php">Выйти из профиля</a></li>
		</div>
	</ul>
</nav>



<!-- Содержимое страницы -->
<div class="content">
  <div class="panel panel-default">
  		<div class="panel-body">
   


    				<div class="content-prof">

    			<?php
            $user_id = $_SESSION['user']['user_id'];

            $check_zak = mysqli_query($connect, "SELECT distinct application.id_app, application.fio, application.email, application.tel, application.time_from, application.time_to, status.name_status, status.id_status, application.id_status, status.id_status FROM `application`,`status`, `users` WHERE status.id_status = application.id_status and users.user_id = application.user_id;");
				   

				   $result = mysqli_query( $connect, "SELECT distinct application.id_app FROM `application`;" );

				  
				   

				   if (mysqli_num_rows($result) != 0){
						
						$arr = [];
						$arr2 = [];
						$counter = 0;
							foreach($check_zak as $zak) :
                            
          ?>

							<div class="zag">
								<h1>Заявка</h1>
							</div>
							<div class="userInfo">
								<?php $id_app = $zak['id_app']?>
								<p>Номер заявки:	<?php echo $id_app; ?> </p>
								<p>ФИО клиента:	<?php echo ($zak['fio']); ?></p>
								<p>Электронная почта клиента:	<span style="color: red"><?php echo ($zak['email']);?></span></p>
								<p>Номер телефона клиента:	<?php echo ($zak['tel']); ?></p>
								<p>Указанное клиентом время:	<?php echo ($zak['time_from']); ?> - <?php echo ($zak['time_to']); ?></p>



								<?php if($zak['id_status']=='0'){ 
									echo '<p class="pbtn" style="background-color: orange; font-weight: 900">' . $zak['name_status'] . '</p>';
								} elseif ($zak['id_status']=='1') {
									echo '<p class="pbtn" style="background-color: green; font-weight: 900">' . $zak['name_status'] . '</p>';
								} elseif($zak['id_status']=='2'){
									echo '<p class="pbtn" style="background-color: red; font-weight: 900">' . $zak['name_status'] . '</p>';
								} 
								?>

								<?php

								 $new_status = mysqli_query($connect, "SELECT status.name_status, status.id_status FROM `status`");

								 ?>

								<form method="POST" action="changeStatus.php?id=<?=$id_app?>">
							   <p><select name = "num" id="select_">

							   	<?php

							   	foreach($new_status as $new_st) :
									$id_status = $new_st['id_status'];
									$arr2[] = intval($id_status);
									
										// if ($id_status == 0){
							   		?>

							   		
							    <option value="<?php echo $id_status?>"><?php echo ($new_st['name_status']);?></option>
							  

									<?php
										// }
									?>

							    <?php

                        endforeach;


               		?>
							   </select></p>
							   <p><input id="<?php $id_app_in = $zak['id_app']; echo $id_app_in?>" type="submit" value="Изменить статус"  onclick="getValue()"></p>
							  </form>

       
  					</div>

  						<?php

  											$counter++;
  											$arr[] = intval($id_app_in);
  											
  											
  											// print_r($arr);
  											// print_r($id_status);
  											// print_r($arr2);
  											//  unset($arr2);
                       	// print_r($arr2);
  											
  											// unset($id_status);
                        endforeach;
                         $_SESSION['arr'] = $arr;
                         $_SESSION['arr2'] = $arr2;



              ?>          




		              	

                <!--  <p> Sum: <?php echo $counter;?></p> -->

                       <!--  $_SESSION['array_name'] = $array_name; -->
               <?php
               } else{
               ?>
              <h2>Пока нет заявок на консультирование</h2>

              <?php
            	}
           	  ?>


						</div>


<!-- <h2>У вас пока нет заявок на консультирование</h2> -->
			</div>
	</div>
</div> 

</body>


</html> 