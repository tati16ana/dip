<?php

  session_start();
	require_once 'connect.php';


?>


<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Личный кабинет</title>
	<link rel="stylesheet" href="styleprofileuser.css">
	<!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous"> -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">



</head>


<body>

<div class="nav-menu">
	<!-- Боковая панель -->
	<div class="sidebar">
	<img class="img-log" src="img/logo.png" alt="">

	  <a class="active" href="#home">Главная</a>
	  <a href="#news">Заявки на консультирование</a>
	  <a href="#contact">Бронирование квартиры</a>
	  

		<div class="help-num">
			<div class="container"> 
				<div class="cards-holder"> 
						<div class="card-title">
							Мы поможем! 
						</div>

						<div class="card-desc">
							Позвоните по номеру</br> 
							<span>+7 950 497-50-55</span> </br> на горячую линию для консультации
						</div>
				</div>
			</div>
		</div>
	</div>
</div>


<!-- Содержимое страницы -->
<div class="content">
 
<h1>Ваш профиль</h1>

<!--  <nav class="navbar bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">
      <img src="/docs/5.3/assets/brand/bootstrap-logo.svg" alt="Logo" width="30" height="24" class="d-inline-block align-text-top">
      Bootstrap
    </a>
  </div>
</nav>
 -->

</div> 
</body>


</html>