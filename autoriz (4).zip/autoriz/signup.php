	
<?php

	session_start();
	require_once 'connect.php';


	
	$fio = $_POST['fio'];
	$login = $_POST['login'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$password_confirm = $_POST['password_confirm'];

	if ($password === $password_confirm){

	$password = md5($password);


	mysqli_query($connect, "INSERT INTO `users` (`user_id`, `fio`, `login`, `email`, `password`) VALUES (NULL, '$fio', '$login', '$email', '$password')");

		$_SESSION['massage'] = 'Регистрация прошла успешно'; 
		header('Location: index.php');




	}else{
		$_SESSION['massage'] = 'Пароли не совпадают'; 
		header('Location: register.php');
	}

?>
