<?php

 session_start();
 	include 'connect.php';

?>





<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Заявки на консультирование</title>
	<link rel="stylesheet" href="styleapplication.css">

	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">


 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/css/bootstrap.min.css" integrity="sha384-r4NyP46KrjDleawBgD5tp8Y7UzmLA05oM1iAEQ17CSuDqnUK2+k9luXQOfXJCJ4I" crossorigin="anonymous">
  <style  
        type="text/css" media="all">
        @import url("styleapplication.css");
  </style>

</head>


<body>

<nav class="navbar">
	<div class="logo">
	<li><a href="profileuser2.php">Профиль</a></li>	
	</div>	
	<ul class="nav-lonks">
		<input type="checkbox" id="checkbox_toggle" />
		<label for="checkbox_toggle" class="hamburger"><span class="hamburger-line"></span></label>
		<div class="menu">
					<li><a href="application.php">Заявки на консультирование</a></li>	
					<li><a href="reservationUser.php">Бронирование квартиры</a></li>	
					<li><a href="logout.php">Выйти из профиля</a></li>
		</div>
	</ul>
</nav>


								<h1>Ваша заявка</h1>
							</div>
							<div class="userInfo">
								<p>Номер заявки:	<?php echo ($zak['id_app']); ?></p>
								<p>Ваше ФИО:	<?php echo ($zak['fio']); ?></p>
								<p>Ваша электронная почта:	<?php echo ($zak['email']);?></p>
								<p>Ваш номер телефона:	<?php echo ($zak['tel']); ?></p>
								<p>Указанное вами время:	<?php echo ($zak['time_from']); ?> - <?php echo ($zak['time_to']); ?></p>

								<?php if($zak['name_status']=='На рассмотрении'){ 
									echo '<p style="background-color: orange; font-weight: 900">' . $zak['name_status'] . '</p>';
								} elseif ($zak['name_status']=='Выполнена') {
									echo '<p style="background-color: green; font-weight: 900">' . $zak['name_status'] . '</p>';
								} elseif($zak['name_status']=='Отклонена'){
									echo '<p style="background-color: red; font-weight: 900">' . $zak['name_status'] . '</p>';
								} 
								?>

  						</div>

  						<?php
                        endforeach;
               } else{
               ?>
              
              <h2>У вас пока нет заявок на консультирование</h2>

              <?php
            	}
           	  ?>


						</div>


<!-- <h2>У вас пока нет заявок на консультирование</h2> -->
			</div>
	</div>
</div> 

</body>


</html> 