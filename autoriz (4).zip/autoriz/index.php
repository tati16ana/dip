<?php
	session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Авторизация</title>
	<link rel="stylesheet" href="style.css">
</head>

<body>
	<!-- Форма авторизации -->

	<form action="signin.php" method="post">
		<label>Логин</label>
		<input type="text" name="login" placeholder="Введите свой логин">
		<label>Пароль</label>
		<input type="password" name="password" placeholder="Введите свой пароль">
		<button type="submit">Войти</button>
		<p class="reg">У вас нет аккаунта? <span>_</span><a href="register.php">Зарегистрируйтесь</a></p>

		<?php
			if ($_SESSION['massage'] == 'Регистрация прошла успешно'){
				echo '<p class="msgok"> ' .$_SESSION['massage'] . ' </p>';
			}
	

			if ($_SESSION['massage'] == 'Неверный логин или пароль'){
				echo '<p class="msg"> ' .$_SESSION['massage'] . ' </p>';
			}
			unset($_SESSION['massage']);
		?>
	</form>
</body>
</html>