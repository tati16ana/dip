<?php

	session_start();
    require_once 'connect.php';
       
   $id_status = $_POST['num'];
   $id_app = $_GET['id'];
   

     $new_stat = mysqli_query($connect, "UPDATE `application` SET application.id_status=$id_status WHERE application.id_app = $id_app;");

  header('Location: applicationAdminProb.php');

?>