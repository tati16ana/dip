<?php

 session_start();
 	include 'connect.php';

?>





<!DOCTYPE html>
<html lang="en">
<head>
	<!-- <meta http-equiv="Refresh" content="1" /> -->

	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Заявки на консультирование</title>
	<!-- <link rel="stylesheet" href="styleappAdmin.css"> -->

	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">


 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/css/bootstrap.min.css" integrity="sha384-r4NyP46KrjDleawBgD5tp8Y7UzmLA05oM1iAEQ17CSuDqnUK2+k9luXQOfXJCJ4I" crossorigin="anonymous">
  <style  
        type="text/css" media="all">
        @import url("styleappAdminProb.css");
  </style>

</head>


<body>




<nav class="navbar">
	<div class="logo">
	<li><a href="profileuser2.php">Профиль</a></li>	
	</div>	
	<ul class="nav-lonks">
		<input type="checkbox" id="checkbox_toggle" />
		<label for="checkbox_toggle" class="hamburger"><span class="hamburger-line"></span></label>
		<div class="menu">
					<li><a href="applicationAdmin.php">Заявки на консультирование</a></li>	
					<li><a href="reservationAdmin.php">Бронирование квартиры</a></li>	
					<li><a href="profileUsersAdmin.php">Профили пользователей</a></li>
					<li><a href="logout.php">Выйти из профиля</a></li>
		</div>
	</ul>
</nav>



<!-- Содержимое страницы -->
<div class="content">
  <div class="panel panel-default">
  		<div class="panel-body">



<div class="content-menu">
  			<form style="display: flex; width: 100%; margin-bottom: 5%;" method="POST" action="changeStatus.php?id=<?=$id_app?>">
							   <select name = "num2" id="select_two" style="padding: 1%; width: 20%; margin-right: 3%;">
							   	<div class="selectVisible"">
							   	<option >Выберите статус</option>


							   	<?php

							   	 $new_status = mysqli_query($connect, "SELECT status.name_status, status.id_status FROM `status`");

							   	foreach($new_status as $new_st) :
									$id_status = $new_st['id_status'];
									$arr2[] = intval($id_status);
									
							   	?>

							   		
							    <option value="<?php echo $id_status?>" style="font-size: 1em; width: 10%"><?php echo ($new_st['name_status']);?></option>
							  

							    <?php
                        endforeach;
               		?>
               		
               	 </div>
							   </select>
							   <input style=" padding: 1%;
    						width: 20%;" style="font-size: 1em;" id="" type="submit" value="Применить сортировку"  onclick="getValue()">
				</form>
   

</div>

    				<div class="content-prof">
<?php
            $user_id = $_SESSION['user']['user_id'];

            $check_zak = mysqli_query($connect, "SELECT distinct application.id_app, application.fio, application.email, application.tel, application.time_from, application.time_to, status.name_status, status.id_status, application.id_status, status.id_status FROM `application`,`status`, `users` WHERE status.id_status = application.id_status and users.user_id = application.user_id;");
             $result = mysqli_query( $connect, "SELECT distinct application.id_app FROM `application`;" );
             $time = mysqli_query( $connect, "SELECT application.time_from FROM `application`" );
 ?>
    			
  <table id="customers">

   <tr>
   	<th>Номер заявки</th>
    <th>ФИО клиента</th>
    <th>Электронная почта клиента</th>
    <th>Номер телефона клиента</th>
    <th class="timeTH" style="width:10%;">Указанное клиентом время</th>
    <th style="width:11%;">Статус заявки</th>
    <th style="width:17.3%;" id="thSt">Изменить статус заявки</th>
    <th style="width:15%;">Применить изменения</th>
  </tr>

    	<?php
    			if (mysqli_num_rows($result) != 0){
            foreach($check_zak as $zak) :
				   ?>
				   <?php $id_app = $zak['id_app']?>
	<tr>			   
  <td style="color=#000"> <?php echo $id_app;?> </td>
  <td style="color=#000"> <?php echo ($zak['fio']);?> </td>
  <td style="color=#000"> <?php echo ($zak['email']); ?> </td>
  <td style="color=#000"> <?php echo ($zak['tel']); ?> </td>
  <?php
    			if (mysqli_num_rows($time) != 0){
  ?>
  <td style="color=#000"> <?php echo ($zak['time_from']); ?> - <?php echo ($zak['time_to']); ?> </td>
 	<?php
      }
   ?>

  <?php if($zak['id_status']=='0'){ 
									echo '<td class="pbt" style="background-color: #ffa500a8; font-weight: 900; paddind: 0 0; color: #000000a6;">' . $zak['name_status'] . '</td>';
								} elseif ($zak['id_status']=='1') {
									echo '<td class="pbt" style="background-color: #0080008f; font-weight: 900; paddind: 0 0;  color: #000000a6;">' . $zak['name_status'] . '</td>';
								} elseif($zak['id_status']=='2'){
									echo '<td class="pbt" style="background-color: #ff00008c; font-weight: 900; paddind: 0 0;  color: #000000a6;">' . $zak['name_status'] . '</td>';
								} 
								?> </td>

			<?php

								 $new_status = mysqli_query($connect, "SELECT status.name_status, status.id_status FROM `status`");

			?>					


	<form method="POST" action="changeStatus.php?id=<?=$id_app?>">
								
							   <td><select name = "num" id="select_">
							   	<div class="selectVisible" style=" display: flex; justify-content: center; position: relative; ">
							   	<option >Выберите статус</option>
							   	<?php

							   	foreach($new_status as $new_st) :
									$id_status = $new_st['id_status'];
									$arr2[] = intval($id_status);
									
										// if ($id_status == 0){
							   		?>

							   		
							    <option value="<?php echo $id_status?>" style="font-size: 1.3rem;"><?php echo ($new_st['name_status']);?></option>
							  

									<?php
										// }
									?>

							    <?php

                        endforeach;


               		?>
							   </select></td>
							   </div>
							   <td><input style="font-size: 1.3rem;" id="<?php $id_app_in = $zak['id_app']; echo $id_app_in?>" type="submit" value="Изменить статус"  onclick="getValue()"></td>
							  </form>

  <?php

    endforeach;
    } else{
	?>
	 <h2>Пока нет заявок на консультирование</h2>
	 <?php
      }
   ?>
  </tr>

 
   
</table>




<!-- ТАБЛИЦЫ ПОД МОБИЛЬНЫЕ УСТРОЙСТВА -->

<table id="customers_mobile">
<!-- <div class="tm"> -->
 <!--   <tr>
   	<th>Номер заявки</th>
    <th>ФИО клиента</th>
    <th>Электронная почта клиента</th>
    <th>Номер телефона клиента</th>
    <th class="timeTH" style="width:10%;">Указанное клиентом время</th>
    <th style="width:11%;">Статус заявки</th>
    <th style="width:17%;">Изменить статус заявки</th>
    <th style="width:15%;">Применить изменения</th>
  </tr> -->
<div class="border" style="border: 3px solid #0c183b;">
    	<?php
    			if (mysqli_num_rows($result) != 0){
            foreach($check_zak as $zak) :
				   ?>
				   <?php $id_app = $zak['id_app']?>
	<tr>
	<th>Номер заявки</th>			   
  <td style="color=#000"> <?php echo $id_app;?> </td>
  </tr>

  <tr>
  <th>ФИО клиента</th>
  <td style="color=#000"> <?php echo ($zak['fio']);?> </td>
  </tr>

  <tr>
  <th>Электронная почта клиента</th>
  <td style="color=#000"> <?php echo ($zak['email']); ?> </td>
  </tr>

  <tr>
  <th>Номер телефона клиента</th>
  <td style="color=#000"> <?php echo ($zak['tel']); ?> </td>
  </tr>
  <?php
    			if (mysqli_num_rows($time) != 0){
  ?>
  <th class="timeTH" style="width:10%;">Указанное клиентом время</th>
  <td style="color=#000;"> <?php echo ($zak['time_from']); ?> - <?php echo ($zak['time_to']); ?> </td>
 	<?php
      }
   ?>

 <tr>
 <th style="width:11%;">Статус заявки</th>
  <?php if($zak['id_status']=='0'){ 
									echo '<td class="pbt" style="background-color: #ffa500a8; font-weight: 900; paddind: 0 0; color: #000000a6;">' . $zak['name_status'] . '</td>';
								} elseif ($zak['id_status']=='1') {
									echo '<td class="pbt" style="background-color: #0080008f; font-weight: 900; paddind: 0 0;  color: #000000a6;">' . $zak['name_status'] . '</td>';
								} elseif($zak['id_status']=='2'){
									echo '<td class="pbt" style="background-color: #ff00008c; font-weight: 900; paddind: 0 0;  color: #000000a6;">' . $zak['name_status'] . '</td>';
								} 
								?> 
 </tr>

			<?php

								 $new_status = mysqli_query($connect, "SELECT status.name_status, status.id_status FROM `status`");

			?>					


	<form method="POST" action="changeStatus.php?id=<?=$id_app?>">
								<tr>
								<th style="width:17%;">Изменить статус заявки</th>
							   <td><select name = "num" id="select_">
							   	<div class="selectVisible" style=" display: flex; justify-content: center; position: relative; ">
							   	<option >Выберите статус</option>
							   	<?php

							   	foreach($new_status as $new_st) :
									$id_status = $new_st['id_status'];
									$arr2[] = intval($id_status);
									
										// if ($id_status == 0){
							   		?>

							   		
							    <option value="<?php echo $id_status?>" style="font-size: 1em; width: 10%"><?php echo ($new_st['name_status']);?></option>
							  

									<?php
										// }
									?>

							    <?php

                        endforeach;


               		?>
							   </select></td>
							   </div>
							  </tr>
							  <tr>
							   <th style="width:15%;">Применить изменения</th>
							   <td><input style="font-size: 1em;" id="<?php $id_app_in = $zak['id_app']; echo $id_app_in?>" type="submit" value="Изменить статус"  onclick="getValue()"></td>
							   </tr>
							  </form>

							  <td style="height: 50%; color: #fff; background-color:#fff; font-size: 4em; border: 0px solid #fff;">d</td>
	<!-- </div> -->

  <?php

    endforeach;
    } else{
	?>
	 <h2>Пока нет заявок на консультирование</h2>
	 <?php
      }
   ?>
  </tr>

 </div>
   
</table>











<style>
	#customers{
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 100%;
    border: 3px solid #ddd;
	}	

	#customers td, #customers th {
    border: 3px solid #ddd;
   /* margin: 5%;*/
   padding: 1%;
   font-size: 1.4em;
   color: #000000e3;
	}

	#customers tr:nth-child(even){background-color: #f2f2f2;}

	#customers tr:hover {background-color: #ddd;}

	#customers th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #48454d;
    color: white;
	}

	@media (min-width: 1201px){
	#customers_mobile{
		display: none;
	}
	}
	
	@media (max-width: 1200px){
		.content-prof {
    width: 100%;
}

		#customers_mobile{
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 100%;
		}	
			#customers td, #customers th {
			display: none;
			border: 5px solid #ddd;
			}

		#customers td{
    border: 3px solid #ddd;
   font-size: 1.4em;
   color: #000000e3;
	}

	#customers_mobile th,#customers_mobile td{
		border: 3px solid #ddd;
   font-size: 1.4em;
   color: #000000e3;
	}


	#customers_mobile tr:nth-child(even){background-color: #f2f2f2;}

	#customers_mobile tr:hover {background-color: #ddd;}

	#customers_mobile th {
    padding: 2%;
    text-align: left;
    background-color: #48454d;
    color: white;
    width: 30%;
    font-size: 1.7em;
	}

	#customers_mobile td {
    text-align: center;
    font-size: 1.8em;
	}

	.tm{
		margin-top: 10%;
	}

	.content-prof{
		width: 50%;
	}

	.panel-body {
    padding: 15px;
    display: flex;
    justify-content: center;
    
}

.panel-default {
    width: 70%;
}

div.content, .btz {
    margin: 5%;
    padding: 0px;
    height: 100%;
    display: flex;
    background-color: #fff;
    justify-content: center;
    align-items: center;
    /* width: 100%; */
}


.content-prof {
    display: flex;
    justify-content: center;
    width: 100%;
    flex-direction: column;
    height: 100%;
    font-family: Roboto;
    margin-left: 0%;
    color: #0c183b;
}

select, input {
    font-size: 1em;
    font-family: Roboto;
    color: #0c183b;
    border: 3px solid #0c183b;
    padding: 7%;
    width: 100%;
    word-wrap: break-word;
}

select{
		display: flex;
    text-align: center;
}

}


	@media (max-width: 800px){
		.panel-default {
    	width: 100%;
    	margin: 0;
		}
	}

	@media (max-width: 400px){
		#customers_mobile td, #customers_mobile th {
    	font-size: 1em;
	}


</style>

	</div>



			</div>
	</div>
</div> 

</body>


</html> 