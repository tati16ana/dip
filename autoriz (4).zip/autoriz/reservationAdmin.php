<?php

 session_start();
 	include 'connect.php';

?>





<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Бронирование квартир</title>
	<link rel="stylesheet" href="styleresUser.css">

	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">


 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/css/bootstrap.min.css" integrity="sha384-r4NyP46KrjDleawBgD5tp8Y7UzmLA05oM1iAEQ17CSuDqnUK2+k9luXQOfXJCJ4I" crossorigin="anonymous">
  <style  
        type="text/css" media="all">
        @import url("styleresUser.css");
  </style>

</head>


<body>




<nav class="navbar">
	<div class="logo">
	<li><a href="admin.php">Профиль</a></li>	
	</div>	
	<ul class="nav-lonks">
		<input type="checkbox" id="checkbox_toggle" />
		<label for="checkbox_toggle" class="hamburger"><span class="hamburger-line"></span></label>
		<div class="menu">
					<li><a href="applicationAdmin.php">Заявки на консультирование</a></li>	
					<li><a href="reservationAdmin.php">Бронирование квартиры</a></li>
					<li><a href="profileUsersAdmin.php">Профили пользователей</a></li>	
					<li><a href="logout.php">Выйти из профиля</a></li>
		</div>
	</ul>
</nav>



<!-- Содержимое страницы -->
<div class="content">
  <div class="panel panel-default">
  		<div class="panel-body">
   


    				<div class="content-prof">

    			<?php
            $user_id = $_SESSION['user']['user_id'];

            $check_zak = mysqli_query($connect, "SELECT DISTINCT reservation.res_id, reservation.id_apart, users.fio, users.email, apartmants.id_apart_type, apartmants.id_apart, apartments_type.apart_name,reservation.id_apart, status_res.id_status_res, status_res.name_status_res FROM `reservation`,`users`, `status_res`, `apartments_type`, `apartmants` WHERE reservation.id_apart = apartmants.id_apart AND apartmants.id_apart_type = apartments_type.id_apart_type AND reservation.id_status_res = status_res.id_status_res AND users.user_id = reservation.user_id;");

				   

				   $result = mysqli_query( $connect, "SELECT reservation.res_id FROM `reservation`;" );
				   
					 // $results =  mysqli_num_rows((int)$result);

				   if (mysqli_num_rows($result) != 0){
						
							$arr = [];
							$counter = 0;
							foreach($check_zak as $zak) :
                            
              // for ($i = 0; $i < $results; $i++){              
          ?>

							<div class="zag">
								<h1>Заявка</h1>
							</div>
							<div class="userInfo">
								<p>Номер заявки:	<?php echo ($zak['res_id']); ?></p>
								<p>ФИО клиента:	<?php echo ($zak['fio']); ?></p>
								<p>Электронная почта клиента:	<?php echo ($zak['email']);?></p>
								<p>Наименование квартиры:	<?php echo ($zak['apart_name']); ?></p>
								<?php $res_id = $zak['res_id']?>
								<p class="aInfo"><a href="infoFlatAdmin.php?id=<?=$res_id?>" style="color: #0c183b; font-weight: 900;" id="<?php $res_id = $zak['res_id']; echo $res_id?>">Посмотреть информацию о квартире</a></p>

								<?php if($zak['name_status_res']=='На рассмотрении'){ 
									echo '<p style="background-color: orange; font-weight: 900">' . $zak['name_status_res'] . '</p>';
								} elseif ($zak['name_status_res']=='Выполнена') {
									echo '<p style="background-color: green; font-weight: 900">' . $zak['name_status_res'] . '</p>';
								} elseif($zak['name_status_res']=='Отклонена'){
									echo '<p style="background-color: red; font-weight: 900">' . $zak['name_status_res'] . '</p>';
								} 
								?>

  						</div>

  						<?php

  											$counter++;


  											$arr[] = intval($zak['res_id']);
  											// echo $arr[];
											// }
											// print_r($arr);
											// unset($arr);
                        endforeach;
                         $_SESSION['arr'] = $arr;
                         // header ("LOcation: infoFlatAdmin.php");
                         $_SESSION['counter'] = $counter;
                         // header ("LOcation: infoFlatAdmin.php");

              ?>          

                 <!-- <p> Sum: <?php echo $counter;?></p> -->

                       <!--  $_SESSION['array_name'] = $array_name; -->
               <?php
               } else{
               ?>
              <h2>Пока нет заявок на бронирование</h2>

              <?php
            	}
           	  ?>



						</div>


<!-- <h2>У вас пока нет заявок на консультирование</h2> -->
			</div>
	</div>
</div> 

</body>


</html> 