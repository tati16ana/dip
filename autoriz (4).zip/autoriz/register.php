<?php
	session_start();
?>


<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="style.css">
</head>

<body>
	<!-- Форма регистрации -->

	<form action="signup.php" method="post">

		<label>E-mail</label>
		<input type="email" name="email" placeholder="Введите адрес вашей электронной почты">

		<label>ФИО</label>
		<input type="text" name="fio" placeholder="Введите ваше имя, фамилию и отчетсво">

		<label>Логин</label>
		<input type="text" name="login" placeholder="Придумайте логин">

		<label>Пароль</label>
		<input type="password" id="password-input" name="password" placeholder="Придумайте пароль">

		<label>Подтверждение пароля</label>
		<input type="password"  id="password-inputTwo" name="password_confirm" placeholder="Повторите пароль">

		<label><input type="checkbox" name="cb" class="password-checkbox" onclick="myFunction()"> Показать пароль</label>

		<script>
			function myFunction() {
		   		var x = document.getElementById("password-input");
		   		var y = document.getElementById("password-inputTwo");
		    	if (x.type === "password") {
		        x.type = "text";
		    	} else {
		        x.type = "password";
		    	}

		    	if (y.type === "password") {
		        y.type = "text";
		    	} else {
		        y.type = "password";
		    	}
			}	

		</script>

		<button type="submit">Зарегистрироваться</button>
		<p class="reg">У вас уже есть аккаунт? <span>_</span><a href="index.php">Вернуться к авторизации</a></p>
		<?php
			if ($_SESSION['massage']){
				echo '<p class="msg"> ' .$_SESSION['massage'] . ' </p>';
			}
			unset($_SESSION['massage']);
		?>
	</form>
</body>
</html>