<?php
	session_start();
	require_once 'connect.php';

	$role = $_POST['role'];
	$login = $_POST['login'];
	$password = md5($_POST['password']);

	$check_user = mysqli_query($connect, "SELECT * FROM `users` WHERE `login` = '$login'AND `password` = '$password'");
	
	if (mysqli_num_rows($check_user) > 0){

		$user = mysqli_fetch_assoc($check_user);
		$_SESSION['user'] = [
			"user_id" => $user['user_id'], 
			"fio" =>  $user['fio'], 
			"login" =>  $user['login'], 
			"email" =>  $user['email'],
			"role" => $user['id_role']
		];
		$_SESSION['user_id'] = $user['user_id'];
		 
		if($user['id_role'] == 1){
			header('Location: admin.php');
		} else {
			
			header('Location: profileuser2.php');

		}




	if (password_verify($_POST['password'], $hash)) {
		$_SESSION['auth'] = true;
		$_SESSION['id'] = $user['id'];
	}
		//header('Location: profileuser.php');

	}else{
		$_SESSION['massage'] = 'Неверный логин или пароль'; 
		header('Location: index.php');
	}
?>
