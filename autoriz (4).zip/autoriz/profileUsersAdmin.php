<?php

 session_start();
 	include 'connect.php';

?>





<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Профили пользователей</title>
	<link rel="stylesheet" href="profileUsersAdmin.css">

	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">


 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/css/bootstrap.min.css" integrity="sha384-r4NyP46KrjDleawBgD5tp8Y7UzmLA05oM1iAEQ17CSuDqnUK2+k9luXQOfXJCJ4I" crossorigin="anonymous">
  <style  
        type="text/css" media="all">
        @import url("profileUsersAdmin.css");
  </style>

</head>


<body>




<nav class="navbar">
	<div class="logo">
	<li><a href="admin.php">Профиль</a></li>	
	</div>	
	<ul class="nav-lonks">
		<input type="checkbox" id="checkbox_toggle" />
		<label for="checkbox_toggle" class="hamburger"><span class="hamburger-line"></span></label>
		<div class="menu">
					<li><a href="applicationAdmin.php">Заявки на консультирование</a></li>	
					<li><a href="reservationAdmin.php">Бронирование квартиры</a></li>	
					<li><a href="profileUsersAdmin.php">Профили пользователей</a></li>	
					<li><a href="logout.php">Выйти из профиля</a></li>
		</div>
	</ul>
</nav>



<!-- Содержимое страницы -->
<div class="content">
  <div class="panel panel-default">
  		<div class="panel-body">
   


    				<div class="content-prof">

    			<?php
            $user_id = $_SESSION['user']['user_id'];

            $check_zak = mysqli_query($connect, "SELECT DISTINCT users.user_id, users.fio, users.login, users.email,  users.id_role, role.id_role, role.role_name FROM `users`, `role` WHERE users.id_role = role.id_role");

				   

				   $result = mysqli_query( $connect, "SELECT users.user_id FROM `users`;" );
				   
					 // $results =  mysqli_num_rows((int)$result);

				   if (mysqli_num_rows($result) != 0){
						
							$arr = [];
							$counter = 0;
							foreach($check_zak as $zak) :
                            
              // for ($i = 0; $i < $results; $i++){              
          ?>

							<div class="zag">
								<h1>Данные пользователя № <?php echo ($zak['user_id']);?></h1>
							</div>
							<div class="userInfo">
							
								<p>ФИО пользователя:	<?php echo ($zak['fio']); ?></p>
								<p>Электронная почта пользователя:	<?php echo ($zak['email']);?></p>
								<p>Логин пользователя:	<?php echo ($zak['login']); ?></p>
								<p>Роль пользователя:	<?php echo ($zak['role_name']); ?></p>
								<?php $user_id = $zak['user_id']?>
								<p class="aInfo"><a href="deleteUser.php?id=<?=$user_id?>" style="color: red; font-weight: 900;" id="<?php $res_id = $zak['res_id']; echo $res_id?>">Удалить пользователя</a></p>

  						</div>

  						<?php

  											$counter++;


  											$arr[] = intval($zak['res_id']);
  											
                        endforeach;
                         $_SESSION['arr'] = $arr;
                        
                         $_SESSION['counter'] = $counter;



            }
                        
              ?>          




<script type="text/javascript" src="jquery-1.9.1.min.js"></script>





<script>
function alert(content,afterFunction){
 $('<div class="alertm_overlay"></div>').appendTo('body');
 $('<div class="alertm_all"><a href="#" onclick="alert_close('+afterFunction+'); return false" class="alertm_close">x</a><div class="alertm_wrapper">'+content+'</div><div class="alertm_but" onclick="alert_close('+afterFunction+'); return false">OK</div></div>').appendTo('body');
 $(".alertm_overlay, .alertm_all").fadeIn("slow");
 $('.alertm_all').css('margin-top', (-1)*($('.alertm_all').height())+'px');
}
function alert_close(afterFunctionClouse){
$(".alertm_overlay, .alertm_all").remove();
afterFunctionClouse;
}


$(document).ready(function(){
alert('<?php  if ($_SESSION['massage']){
            			echo $_SESSION['massage'];
            			unset($_SESSION['massage']);
            		}else{ echo("Подтвердите действие на странице"); 
            		}	
            		?>');
});
</script>







<style>
.alertm_overlay {    
	width:100%;    
	height:100%;    
	position:fixed;    
	left:0px;    
	top:0px;    
	z-index:99998;    
	background:rgba(51, 51, 51, 0.82);  
	display:none;
}
.alertm_all {
	font-family: Arial;    
	width:396px;    
	padding:29px 43px;    
	border-radius: .25rem;  
	background:#fff;    
	position:fixed;    
	left:50%;    
	margin-left:-241px;    
	top:50%;    
	z-index:99999;    }
.alertm_all a {    
	-webkit-transition: all .2s ease-in-out;    
	-o-transition: all .2s ease-in-out;    
	transition: all .2s ease-in-out;    
	text-decoration: none;    
	color: #0275d8;}
.alertm_all a:hover {
    color: #222;}
.alertm_h1 {
    color: #0275d8;    
    font-size: 2.0rem;    
    margin-bottom: 15px;}
.alertm_text {   
	font-size: 2.0 rem;    
	line-height: 10%;}
.alertm_wrapper { 
	font-size: 200%;
}
.alertm_but {    
	display: inline-block;    
	font-weight: 400;    
	line-height: 1.25;    
	text-align: center;    
	white-space: nowrap;    
	vertical-align: middle;    
	-webkit-user-select: none;    
	-moz-user-select: none;    
	-ms-user-select: none;    
	user-select: none;   
	 border: 1px solid transparent;    
	 padding: .5rem 2rem;    
	 font-size: 2rem;    
	 border-radius: .25rem;    
	 -webkit-transition: all .2s ease-in-out;    
	 -o-transition: all .2s ease-in-out;    
	 transition: all .2s ease-in-out;    
	 color: #fff;    
	 background-color: #0c183b;    
	 border-color: #0c183b;    
	 display: block;    
	 margin-top: 25px;    
	 cursor: pointer;
	}
.alertm_but:hover {    
	color: #fff;    
	background-color: #025aa5;    
	border-color: #01549b;
}
a.alertm_close {    
	color: red;    
	text-decoration: none;    
	position: absolute;    
	right: 7px;    
	top: 0px;    
	font-size: 2.0rem;}
</style>


           	 
     
    


						</div>


<!-- <h2>У вас пока нет заявок на консультирование</h2> -->
			</div>
	</div>
</div> 

</body>


</html> 