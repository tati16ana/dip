<?php

 session_start();
 	include 'connect.php';
 	//include 'signin.php';

// 	$user_id = $_GET['id'];
// 	echo $user_id;
// 	$user = mysqli_query($connect, "SELECT * FROM `users` WHERE `id` = '$user_id'");
// 	$user = mysqli_fetch_assoc($user);

// 	 session_start();
//   echo $_SESSION['users'].', добро пожаловать в Личный Кабинет';
// print_r($user);
	 //echo "<link rel='stylesheet' href=/styleprofileuser.css>"; 

?>





<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Личный кабинет</title>
	<link rel="stylesheet" href="styleprofileuser.css">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="../styleprofileuser.css"></link>


 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/css/bootstrap.min.css" integrity="sha384-r4NyP46KrjDleawBgD5tp8Y7UzmLA05oM1iAEQ17CSuDqnUK2+k9luXQOfXJCJ4I" crossorigin="anonymous">
  <style  
        type="text/css" media="all">
        @import url("styleprofileuser.css");
  </style>

</head>


<body>

<!-- <div class="nav-menu"> -->
	<!-- Боковая панель -->
<!-- 	<div class="sidebar"> -->
	<!-- <img class="img-log" src="img/logo.png" alt=""> -->

<!-- 	  <a class="active" href="#home">Главная</a>
	  <a href="#news">Заявки на консультирование</a>
	  <a href="#contact">Бронирование квартиры</a>
	   -->

	<!-- 	<div class="help-num">
			<div class="container"> 
				<div class="cards-holder"> 
						<div class="card-title">
							Мы поможем! 
						</div>

						<div class="card-desc">
							Позвоните по номеру</br> 
							<span>+7 950 497-50-55</span> </br> на горячую линию </br>для консультации
						</div>
				</div>
			</div>
		</div>
	</div>
</div>
 -->



<nav class="navbar">
	
	<div class="logo">LOGO</div>
	<ul class="nav-lonks">
		<input type="checkbox" id="checkbox_toggle" />
		<label for="checkbox_toggle" class="hamburger"><span class="hamburger-line"></span></label>
		<div class="menu">
					<li><a href="#">Дом</a></li>	
					<li><a href="#">О нас</a></li>	
					<li><a href="#">Контакты</a></li>		
		</div>
	</ul>
</nav>



<!-- Содержимое страницы -->
<div class="content">
  <div class="panel panel-default">
  		<div class="panel-body">
   

    				<div class="content-prof">
							<div class="zag">
								<h1>Ваш профиль</h1>
							</div>
							<div class="userInfo">
								<p>Ваше ФИО:	<?= $_SESSION['user']['fio'] ?></p>
								<p>Ваша электронная почта:	<?= $_SESSION['user']['email']?></p>
								<p>Ваш логин:	<?= $_SESSION['user']['login'] ?></p>
								<a href="logout.php">Выйти из аккаунта</a>
  						</div>
						</div>

			</div>
	</div>
</div> 

</body>


</html> 