<?php

 session_start();
 	include 'connect.php';

?>





<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Бронирование квартир</title>
	<link rel="stylesheet" href="infoFlatUser.css">

	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">


 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/css/bootstrap.min.css" integrity="sha384-r4NyP46KrjDleawBgD5tp8Y7UzmLA05oM1iAEQ17CSuDqnUK2+k9luXQOfXJCJ4I" crossorigin="anonymous">
  <style  
        type="text/css" media="all">
        @import url("infoFlatUser.css");
  </style>

</head>


<body>




<nav class="navbar">
	<div class="logo">
	<li><a href="profileuser2.php" class="prof">Профиль</a></li>	
	</div>	
	<ul class="nav-lonks">
		<input type="checkbox" id="checkbox_toggle" />
		<label for="checkbox_toggle" class="hamburger"><span class="hamburger-line"></span></label>
		<div class="menu">
					<li><a href="application.php">Заявки на консультирование</a></li>	
					<li><a href="reservationUser.php">Бронирование квартиры</a></li>	
					<li><a href="logout.php">Выйти из профиля</a></li>
	</ul>
</nav>



<!-- Содержимое страницы -->
<div class="content">
  <div class="panel panel-default">
  		<div class="panel-body">
   


    				<div class="content-prof">

    			<?php
            $user_id = $_SESSION['user']['user_id'];


             $arr = $_SESSION['arr'];
             $counter = $_SESSION['counter'];
            
             $label = 'id';
							$id = false;
							if (  !empty( $_GET[ $label ] )  )
							{
							  $id = $_GET[ $label ];
							}


            $check_zak = mysqli_query($connect, "SELECT apartments_type.img, apartments_type.apart_name, apartments_type.bathroom, apartments_type.corridor, apartments_type.bathroom, apartments_type.housing_class, apartments_type.kitchen, apartments_type.deadline, apartments_type.kitchen_corridor, apartments_type.living_room1, apartments_type.living_room3, apartments_type.living_room2, apartments_type.number, apartments_type.pantry, apartments_type.room2_kithen, apartments_type.square, apartments_type.sum, apartments_type.id_apart_type, apartmants.id_apart, apartmants.id_apart_type, reservation.id_apart, reservation.id_status_res, reservation.res_id, reservation.user_id, users.user_id, status_res.id_status_res, status_res.name_status_res FROM `reservation`,`users`, `apartmants`, `apartments_type`, `status_res` WHERE reservation.user_id = users.user_id AND reservation.id_status_res = status_res.id_status_res AND reservation.id_apart = apartmants.id_apart AND apartmants.id_apart_type = apartments_type.id_apart_type AND reservation.res_id = '$id';");

             $result = mysqli_query( $connect, "SELECT reservation.res_id FROM `reservation`;" );


            if (mysqli_num_rows($result) != 0){

            foreach($check_zak as $zak) :
                            
          ?>

							<div class="zag">
								<h1>Информация о квартире</h1>
							</div>

						<div class="all-obj">
							<div class="img-png"><?php echo "<img src='" . $zak['img'] . "' alt='' />"; ?></div>
							<div class="userInfo">
	
								<p>Наименование квартиры:	<?php echo ($zak['apart_name']);?></p>
								<p>Срок сдачи:	<?php echo ($zak['deadline']); ?></p>
								<p>Общая площадь:	<?php echo($zak['square']); echo(" кв.м.")?></p> 

								<?php if($zak['living_room2'] == 0 & $zak['living_room3'] == 0){
									?>
									<p>Площадь жилой комнаты:	<?php echo($zak['living_room1']); echo(" кв.м.")?></p> 
								<?php 
									} else if($zak['living_room3'] == 0 & $zak['living_room2'] != 0){
								?>
									<p>Площадь 1-ой жилой комнаты:	<?php echo($zak['living_room1']); echo(" кв.м.")?></p> 
									<p>Площадь 2-ой жилой комнаты:	<?php echo($zak['living_room2']); echo(" кв.м.")?></p>
								<?php
									} else{
								?>
									<p>Площадь 1-ой жилой комнаты:	<?php echo($zak['living_room1']); echo(" кв.м.")?></p> 
									<p>Площадь 2-ой жилой комнаты:	<?php echo($zak['living_room2']); echo(" кв.м.")?></p>
									<p>Площадь 3-ей жилой комнаты:	<?php echo($zak['living_room3']); echo(" кв.м.")?></p>
								<?php		
									}
								?>

								<?php if($zak['room2_kithen'] != 0){
									?>
									<p>Площадь кухни-гостинной:	<?php echo($zak['room2_kithen']); echo(" кв.м.")?></p> 

								<?php		
									}
								?>


								<?php if($zak['kitchen'] != 0){
									?>
									<p>Площадь кухни:	<?php echo($zak['kitchen']); echo(" кв.м.")?></p> 

								<?php		
									}
								?>

								<?php if($zak['kitchen_corridor'] != 0){
									?>
									<p>Площадь кухонной зоны и коридора:	<?php echo($zak['kitchen_corridor']); echo(" кв.м.")?></p> 

								<?php		
									}
								?>

								<?php if($zak['bathroom'] != 0){
									?>
									<p>Площадь санузла:	<?php echo($zak['bathroom']); echo(" кв.м.")?></p> 

								<?php		
									}
								?>


								<?php if($zak['corridor'] != 0){
									?>
									<p>Площадь коридора:	<?php echo($zak['corridor']); echo(" кв.м.")?></p> 

								<?php		
									}
								?>


								<?php if($zak['hallway'] != 0){
									?>
									<p>Площадь прихожей:	<?php echo($zak['hallway']); echo(" кв.м.")?></p> 

								<?php		
									}
								?>

								<?php if($zak['pantry'] != 0){
									?>
									<p>Площадь прихожей:	<?php echo($zak['pantry']); echo(" кв.м.")?></p> 

								<?php		
									}
								?>




							
	
  						</div>
  					</div>		

  						<?php
                        endforeach;
              ?>
            
              <p style="background-color: #0c183b; display: flex;
  						justify-content: center;"><a href="reservationUser.php" id="btnExit" style=" text-decoration: none;">Вернуться на страницу с заявками</a></p>

              <?php
               } else{
              
              echo  '<h2>Пока нет заявок на бронирование</h2>';

              
            	}
           	  ?>
						</div>


			</div>
	</div>
</div> 

</body>


</html> 