<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Подтверждение удаления</title>
    <style  
        type="text/css" media="all">
        @import url("deleteUser2.css");
  </style>

</head>
<body>


   <?php

  session_start();
    require_once 'connect.php';

     $label = 'id';
     $id = false;
     if (  !empty( $_GET[ $label ] )  )
     {
       $id = $_GET[ $label ];
     }
     ?>

   <div id="zatemnenie">
             <div id="okno">
                 Вы действительно хотите удалить пользователя?<br>
               <div class="oknoBtn">  
             <a href="delete.php?id=<?=$id?>" class="close">Да</a>
           <a href="profileUsersAdmin.php" class="close">Нет</a>
         </div>
     </div>
  </div>

  <a href="#okno">Подтвердите удаление</a>
  
<script type="text/javascript" src="jquery-1.9.1.min.js"></script>







 

</body>
</html>
