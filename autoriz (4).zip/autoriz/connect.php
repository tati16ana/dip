<?php

	$login = $_POST['login'];
	$password = $_POST['password'];

	$connect = mysqli_connect('localhost', 'root', '', 'prob3');

	if (!$connect){
		die('Error connect to DataBase');
	}



?>