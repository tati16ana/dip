
  <?php

  session_start();
    require_once 'connect.php';

     $label = 'id';
     $id = true;
     if (  !empty( $_GET[ $label ] )  )
     {
       $id = $_GET[ $label ];
     }
     ?>


<?php


      $new_stat = mysqli_query($connect, "DELETE FROM `users` WHERE users.user_id = $id");


      if ($new_stat == true){   
      $_SESSION['massage'] = 'Пользователь удален'; 
       header('Location: profileUsersAdmin.php');
     } elseif($new_stat == false){
       $_SESSION['massage'] = 'Удаление данного пользователя невозможно';
       header('Location: profileUsersAdmin.php');
     }

?>

